var a = 45;
var b = "45";

// console.log(typeof a);
// console.log(typeof b);

// var result1 = a == b;           // Abstract Equality
// console.log(result1);

// var result2 = a === b;           // Strict Equality
// console.log(result2);

var obj1 = new Object();
var obj2 = new Object();

console.log(obj1 == obj2);
console.log(obj1 === obj2);

var obj3 = obj1;

console.log(obj1 == obj3);
console.log(obj1 === obj3);