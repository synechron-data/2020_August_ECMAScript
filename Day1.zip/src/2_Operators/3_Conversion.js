// // Type Casting - Between Similiar (Same Family of) Types       int to float, float to int
// // Type Conversion - Diffent Family of types                    int to string, strig to int

// var data = window.prompt("Enter a number", 0);
// // console.log(typeof data);

// var n1 = data + 10;
// console.log(n1);

// var n2 = parseInt(data) + 10;
// console.log(n2);

// var n3 = parseFloat(data) + 10;
// console.log(n3);

// var n4 = Number(data) + 10;
// console.log(n4);

// var obj = null;
// var obj;
// var obj = {};

// if ((obj === null) || (obj === undefined)) {
// if (!obj) {
//     console.log("Is null or undefined...");
// } else {
//     console.log("Is not null or undefined...");
// }

console.log(true && "ABC");
console.log(true && "ABC" || "XYZ");
console.log(false && "ABC" || "XYZ");