// // Lexical Scoping

// var a = 10;
// console.log("Outside", a);

// // function test() {
// //     console.log("Inside Test", a);
// // }

// // test();

// function test1() {
//     // var a = 1000;
//     console.log("Inside Test 1", a);

//     function test2() {
//         // var a = 10000;
//         console.log("Inside Test 2", a);
//     }

//     test2();
// }

// test1();

// // --------------------------------------------------- Scopes in ES5
// // Global Scope
// // Function Scope (Local)

// var i = "Hello";
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }
// iterate();

// IIFE - Immediatly Invoked Function Expression
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is", i);

// --------------------------------------------------- Scopes in ECMAScript2015 and above
// Global Scope
// Function Scope (Local)
// Block Scope (Only when we use let or const)

var i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);