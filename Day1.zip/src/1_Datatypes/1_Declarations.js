// Add 'use strict' manually if wrting the js files
// or
// use @babel/plugin-transform-strict-mode plugin when your are compiling through babel

// console.log("Hello from declarations.js")

// a = 10;
// console.log(a);

// function test() {
//     var a = 10;
//     console.log("Inside Test, a is", a);
// }

// test();
// console.log("Outside Test, a is", a);

// var a;
// a = 10;
// console.log(a);

// a = "ABC";
// console.log(a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.

// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted
// console.log(a);
// var a = 20;

// Runtime will see the below code
// var a;
// console.log(a);
// a = 20;

