var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = 10;       // base 10
// language = 10.5;
// language = 0b1001;      // base 2
// language = 0o1001;      // base 8
language = 0x1001;      // base 16
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';
// ECMASCript 2015 - Template (String) Literals

language = `Java

Script`;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// ECMAScript 2015 - Symbol
language = Symbol("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Object();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = String(10);
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new String(10);
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);