// What is Pure Function in JavaScript?
// Pure function must return a value. Pure functions are the function which accept arguments but will never modify them

// // ------------------------- With Primitive Types (Immutable)
// var a = 10;

// function modify(x) {
//     x = 1000;
// }

// console.log(`Before - ${a}`);
// modify(a);
// console.log(`After - ${a}`);

// ------------------------- With Complex Types (Mutable)
// var a = [10];

// function modify(x) {
//     x.push(1000);
// }

// console.log(`Before - ${a}`);
// modify(a);
// console.log(`After - ${a}`);

// --------------------------------- Impure & Pure Function
// var arr = [10, 20, 30];

// // function append(dataArr, x) {
// //     dataArr[dataArr.length] = x;
// //     return dataArr;
// // }

// function append(dataArr, x) {
//     var rArr = [...dataArr];
//     rArr[dataArr.length] = x;
//     return rArr;
// }

// var newArr1 = append(arr, 100);      // Expected [10, 20, 30, 100]
// console.log(newArr1);

// var newArr2 = append(arr, 100);      // Expected [10, 20, 30, 100]
// console.log(newArr2);

// ------------------------------------------------------------------------- Assignment
var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) { 

}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);