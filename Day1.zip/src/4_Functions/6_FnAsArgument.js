// document.getElementById("b1").addEventListener("click", function () { });

// $(document).ready(function () {
//     $("#b1").click(function () { 

//     })
// });

// setInterval(function () { }, 2000);

var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// var pune_employees = [];

// for (const employee of employees) {
//     if (employee.city === "Pune")
//         pune_employees.push(employee);
// }

// console.log(pune_employees);

// ------------------------------------------

// var pune_employees = [];

// function filterLogic(employee){
//     return employee.city === "Pune";
// }

// for (const employee of employees) {
//     if (filterLogic(employee))
//         pune_employees.push(employee);
// }

// console.log(pune_employees);

// ------------------------------------------

// function filterLogic(employee){
//     return employee.city === "Pune";
// }

// var pune_employees = employees.filter(filterLogic);

// console.log(pune_employees);

// ------------------------------------------

// var pune_employees = employees.filter(function (employee) {
//     return employee.city === "Pune";
// });

// console.log(pune_employees);

// ------------------------------------------

// var pune_employees = employees.filter((employee) => {
//     return employee.city === "Pune";
// });

// console.log(pune_employees);

// ------------------------------------------

var pune_employees = employees.filter(employee => employee.city === "Pune");
console.log(pune_employees);