// Case 1 - Default Import
// import square from './lib';
// console.log("Result: ", square(20));

// import sqr from './lib';
// console.log("Result: ", sqr(20));

// Case 2 - Named Import
// import { square, check } from './lib';
// console.log("Result: ", square(20));
// console.log("Result: ", check(20));

// import * as lib from './lib';
// console.log("Result: ", lib.square(20));
// console.log("Result: ", lib.check(20));

// Case 3 - Named and Default Import
// import square, { check } from './lib';
// console.log("Result: ", square(20));
// console.log("Result: ", check(20));

// import sqr, { check } from './lib';
// console.log("Result: ", sqr(20));
// console.log("Result: ", check(20));

import Person from './lib';

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());