function* idGenerator() {
    yield 1;
    yield 2;
    yield 3;
    yield 4;
    yield 5;
}

let seq = idGenerator();
// console.log(seq);

for (let i = 0; i < 5; i++) {
    console.log(seq.next());
}