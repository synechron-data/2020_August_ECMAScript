import apiClient from './apiClient';

var button = document.createElement("button");
button.innerHTML = "Get Data";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

button.addEventListener("click", function () {
    // apiClient.getAllPosts((result) => {
    //     console.log(result);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });

    // apiClient.getAllPostsUsingPromise().then((result) => {
    //     console.log(result);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });

    var p = apiClient.getAllPostsUsingPromise();

    p.then((result) => {
        console.log(result);
    }).catch((eMsg) => {
        console.error(eMsg);
    });
});