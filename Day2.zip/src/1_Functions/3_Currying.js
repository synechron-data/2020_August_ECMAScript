// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 74.83, 0, 100));
// console.log(Converter(" INR", 74.83, 0, 150));
// console.log(Converter(" INR", 74.83, 0, 1500));
// console.log(Converter(" INR", 74.83, 0, 900));

// -------------------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// greetings("Good Morning")("Manish");

// function Converter(toUnit, factor, offset) {
//     return function(input){
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var USDtoINR = Converter(" INR", 74.83, 0);

// console.log(USDtoINR(100));
// console.log(USDtoINR(150));
// console.log(USDtoINR(1500));
// console.log(USDtoINR(900));

// var MILEStoKM = Converter(" KM", 1.6, 0);

// console.log(MILEStoKM(100));
// console.log(MILEStoKM(150));
// console.log(MILEStoKM(1500));
// console.log(MILEStoKM(900));

// -----------------------------------------------------------------------

function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

var mGreet = greetings.bind(undefined, "Good Morning");

mGreet("Abhijeet");
mGreet("Ramakant");
mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var USDtoINR = Converter.bind(undefined, " INR", 74.83, 0);

console.log(USDtoINR(100));
console.log(USDtoINR(150));
console.log(USDtoINR(1500));
console.log(USDtoINR(900));