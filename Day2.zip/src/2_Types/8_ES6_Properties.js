class Person {
    constructor(name, age) {
        this._name = name;
        this._age = age;
    }

    get Name() {
        return this._name;
    }

    set Name(name) {
        this._name = name;
    }

    get Age() {
        return this._age;
    }

    set Age(value) {
        this._age = value;
    }
}

var p1 = new Person("Manish", 20);
console.log(p1.Name);
console.log(p1.Age);
p1.Name = "Abhijeet";
p1.Age = 38;
console.log(p1.Name);
console.log(p1.Age);