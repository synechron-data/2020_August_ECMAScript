// ---------------------------------------------------- Object.assign
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let target = source;

// Shallow Copy
// let target = Object.assign({}, source);
// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// Deep Copy
// let target = JSON.parse(JSON.stringify(source));
// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// console.log("Source ", source);
// console.log("Target ", target);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let newSource1 = Object.assign({}, source);
// let newSource2 = Object.create(source);

// console.log("Source ", source);
// console.log("NewSource 1", newSource1);
// console.log("NewSource 2", newSource2);

// ----------------------------------------------------

// let source = { id: 1, name: "Manish" };

// // Modify Property Value
// source.id = 100;
// console.log(source);

// // Add New Property
// source.city = "Pune";
// console.log(source);

// // Delete Property
// delete source.id;
// console.log(source);

// Object.preventExtensions(source);
// // Modify Property Value - Allowed
// // Add New Property - Not Allowed
// // Delete Property - Allowed

// // source.id = 100;
// // delete source.id;

// if (Object.isExtensible(source))
//     source.city = "Pune";

// console.log(source);

// Object.seal(source);
// // Modify Property Value - Allowed
// // Add New Property - Not Allowed
// // Delete Property - Not Allowed

// // source.id = 100;

// if (Object.isSealed(source)) {
//     delete source.id;
//     source.city = "Pune";
// }

// console.log(source);

// Object.freeze(source);
// // Modify Property Value - Not Allowed
// // Add New Property - Not Allowed
// // Delete Property - Not Allowed

// if (!Object.isFrozen(source)) {
//     source.id = 100;
//     delete source.id;
//     source.city = "Pune";
// }

// console.log(source);