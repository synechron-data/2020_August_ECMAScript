// var obj = null;
// console.log(obj);
// console.log(typeof obj);

// var obj1 = new Object();
// console.log(obj1);
// console.log(typeof obj1);

// // JavaScript Object Literal or Values
// var obj2 = {};
// console.log(obj2);
// console.log(typeof obj2);

// JavaScript Object Literal or Values
var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune"
    },
    display: function () {
        console.log(this);
    }
};

var person_JSON = JSON.stringify(person);

console.log(person);
console.log(person_JSON);

console.log(typeof person);
console.log(typeof person_JSON);

var p2 = JSON.parse(person_JSON);
console.log(p2);
console.log(typeof p2);

