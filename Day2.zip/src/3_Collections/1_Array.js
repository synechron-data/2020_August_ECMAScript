// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array("abc", "xyz");
// var employees = new Array(1, 2, 3, 4, 5);
// var employees = new Array([1, 2, 3, 4, 5]);
// var employees = Array.of(1);

// var employees = [];

// employees[0] = "ABC";
// employees[1] = "XYZ";
// employees[2] = "PQR";

// employees.push("Manish");
// // employees.push("Abhijeet");

// employees.unshift("Abhijeet");

// console.log(employees);
// console.log(typeof employees);
// console.log(employees.length);

// ------------------------------------------ Iterate

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
    { id: 6, name: "Abhishek" }
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);
// }

// for (const i in employees) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// });

// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const item of employees.entries()) {
//     console.log(`${JSON.stringify(item)}`);
// }

for (const [i, item] of employees.entries()) {
    console.log(`${i}       ${JSON.stringify(item)}`);
}
