var dev2;

(function (ns) {
    function test() {
        console.log("test from file 2");
    }

    ns.test = test;
})(dev2 = dev2 || {});