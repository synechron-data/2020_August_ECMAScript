var dev1;

(function (ns) {
    function test() {
        console.log("test from file 1");
    }

    ns.test = test;
})(dev1 = dev1 || {});